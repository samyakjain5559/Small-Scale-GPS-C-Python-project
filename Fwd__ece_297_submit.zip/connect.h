/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   connect.h
 * Author: jainsam3
 *
 * Created on February 25, 2019, 11:16 PM
 */
#include <iostream>
#include <string>
//#include "m2.h"
//#include "m1.h"
#include <sstream>;
using namespace std;

//#ifndef CONNECT_H
//#define CONNECT_H

//string p;


//#endif /* CONNECT_H */

